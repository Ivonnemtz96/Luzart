<header class="page_header ls justify-nav-center ">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-xl-2 col-lg-3 col-11">
                <a href="index.php" class="logo">
                    <img src="assets/images/logo.png" alt="img">
                </a>

            </div>
            <div class="col-xl-8 col-1 text-sm-center">
                <nav class="top-nav">
                    <ul class="nav sf-menu">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home</a>

                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php#sobrenosotros">Sobre Nosotros</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="productos.php#productos">Productos</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Nuestros Servicios</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php#contacto">Contacto</a>
                        </li>

                    </ul>

                </nav>
            </div>
        </div>
    </div>
    <!-- header toggler -->
    <span class="toggle_menu"><span></span></span>
</header>