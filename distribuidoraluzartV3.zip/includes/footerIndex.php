<footer hidden class="page_footer ds ms s-py-90 s-py-xl-150 c-gutter-60 dark-gradient leaf-wrap overflow-visible">
    <div class="leaf leaf-left animate animated" data-animation="fadeInUp" data-delay="150">
        <img src="assets/images/footer-leaf-1.png" alt="img">
    </div>
    <div class="leaf leaf-right animate animated" data-animation="fadeInUp" data-delay="150">
        <img src="assets/images/footer-leaf-2.png" alt="img">
    </div>
</footer>

<section class="page_copyright ls s-py-25" style="background-color: #2d3545;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 text-center">
                <p class="color-light">Copyright &copy; <span class="copyright_year">2021</span> Todos los derechos reservados Creado por <a href="https://bananagroup.mx">Banana Group</a></p>
            </div>
        </div>
    </div>
</section>