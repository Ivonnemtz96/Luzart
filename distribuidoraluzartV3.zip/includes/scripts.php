
<script>
	function myFunction() {
		var dots = document.getElementById("dots");
		var moreText = document.getElementById("more");
		var btnText = document.getElementById("myBtn");

		if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "Léer Mas";
			moreText.style.display = "none";
		} else {
			dots.style.display = "none";
			btnText.innerHTML = "Léer Menos";
			moreText.style.display = "inline";
		}
	}

	function myFunction2() {
		var dots = document.getElementById("dots2");
		var moreText = document.getElementById("more2");
		var btnText = document.getElementById("myBtn2");

		if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "Léer Mas";
			moreText.style.display = "none";
		} else {
			dots.style.display = "none";
			btnText.innerHTML = "Léer Menos";
			moreText.style.display = "inline";
		}
	}
</script>

<!-- <script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
<script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
<script src="assets/js/vendor/affix.js"></script>
<script src="assets/js/vendor/jquery.appear.js"></script>
<script src="assets/js/vendor/jquery.cookie.js"></script>
<script src="assets/js/vendor/jquery.easing.1.3.js"></script>
<script src="assets/js/vendor/jquery.hoverIntent.js"></script>
<script src="assets/js/vendor/superfish.js"></script>
<script src="assets/js/vendor/bootstrap-progressbar.min.js"></script>
<script src="assets/js/vendor/jquery.countdown.min.js"></script>
<script src="assets/js/vendor/jquery.countTo.js"></script>
<script src="assets/js/vendor/jquery.easypiechart.min.js"></script>
<script src="assets/js/vendor/jquery.scrollbar.min.js"></script>
<script src="assets/js/vendor/jquery.localScroll.min.js"></script>
<script src="assets/js/vendor/jquery.scrollTo.min.js"></script>
<script src="assets/js/vendor/jquery.ui.totop.js"></script>
<script src="assets/js/vendor/jquery.parallax-1.1.3.js"></script>
<script src="assets/js/vendor/isotope.pkgd.min.js"></script>
<script src="assets/js/vendor/jquery.flexslider-min.js"></script>
<script src="assets/js/vendor/owl.carousel.min.js"></script>
<script src="assets/js/vendor/photoswipe.js"></script>
<script src="assets/js/vendor/photoswipe-ui-default.min.js"></script>
<script src="assets/js/vendor/jflickrfeed.min.js"></script>
<script src="assets/js/vendor/spectragram.min.js"></script>
<script src="assets/twitter/jquery.tweet.js"></script>
<script src="assets/js/vendor/circletype.min.js"></script>
<script src="assets/js/vendor/jquery.marquee.min.js"></script>
<script src="assets/js/main.js"></script>
<!-- <script src="assets/js/switcher.js"></script> -->
<script src="assets/js/filter-sort.js"></script>